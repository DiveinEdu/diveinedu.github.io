//
//  MetalView.swift
//  ClearScreen
//
//  Created by WuQiong on 14/12/15.
//  Copyright (c) 2014年 戴维营教育. All rights reserved.
//

import UIKit
import Metal
import QuartzCore

class MetalView: UIView {
    var _metalLayer: CAMetalLayer!
    var _device: MTLDevice!
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        _metalLayer = self.layer as CAMetalLayer
        _device = MTLCreateSystemDefaultDevice()
        _metalLayer.device = _device;
        _metalLayer.pixelFormat = .BGRA8Unorm
    }
    
    override class func layerClass () -> AnyClass {
        return CAMetalLayer.self
    }

    override func didMoveToWindow() {
        self.redraw();
    }
    
    func redraw() {
        let drawable = _metalLayer.nextDrawable();
        let texture = drawable.texture;
        
        let passDescriptor = MTLRenderPassDescriptor()
        passDescriptor.colorAttachments[0].texture = texture;
        passDescriptor.colorAttachments[0].loadAction = .Clear
        passDescriptor.colorAttachments[0].storeAction = .Store
        passDescriptor.colorAttachments[0].clearColor = MTLClearColorMake(1.0, 0.0, 0.0, 1.0)
        
        let commandQueue = _device.newCommandQueue()
        let commandBuffer = commandQueue.commandBuffer()
        
        let commandEncoder = commandBuffer.renderCommandEncoderWithDescriptor(passDescriptor)
        commandEncoder?.endEncoding()
        
        commandBuffer.presentDrawable(drawable);
        commandBuffer.commit()
    }
}

//
//  ViewController.swift
//  ClearScreen
//
//  Created by WuQiong on 14/12/15.
//  Copyright (c) 2014年 戴维营教育. All rights reserved.
//

import UIKit
import Metal
import QuartzCore

class ViewController: UIViewController {
    var _metalLayer: CAMetalLayer!
    var _device: MTLDevice!
    var _commandQueue: MTLCommandQueue!

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        _metalLayer = CAMetalLayer()
//        _metalLayer.frame = self.view.bounds;
//        
//        _device = MTLCreateSystemDefaultDevice()
//        _metalLayer.device = _device;
//        _metalLayer.pixelFormat = .BGRA8Unorm
//        
//        self.view.layer.addSublayer(_metalLayer)
//        
//        self.redraw()
    }
    
    func redraw() {
        let drawable = _metalLayer.nextDrawable();
        
        let passDescriptor = MTLRenderPassDescriptor()
        passDescriptor.colorAttachments[0].texture = drawable.texture;
        passDescriptor.colorAttachments[0].loadAction = .Clear //
        passDescriptor.colorAttachments[0].storeAction = .Store
        passDescriptor.colorAttachments[0].clearColor = MTLClearColorMake(1.0, 0.0, 0.0, 1.0)
        
        _commandQueue = _device.newCommandQueue()
        let commandBuffer = _commandQueue.commandBuffer()
        
        let commandEncoder = commandBuffer.renderCommandEncoderWithDescriptor(passDescriptor)
        commandEncoder?.endEncoding()
        
        commandBuffer.presentDrawable(drawable);
        commandBuffer.commit()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

